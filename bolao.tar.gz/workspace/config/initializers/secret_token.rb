# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Bolao::Application.config.secret_key_base = '84d6e72f3fb389fbb3ba9d0f5a15942c306ebdc998c995e2a5ec958262032c57a08f13be570daa9f82b1b4e301c031bf9ffdf75ec5036d0edb02c415a1e912c9'
