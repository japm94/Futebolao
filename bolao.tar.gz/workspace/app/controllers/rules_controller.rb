class RulesController < ApplicationController

  def index
  end

end