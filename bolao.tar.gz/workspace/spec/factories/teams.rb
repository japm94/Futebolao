FactoryGirl.define do
  
  factory :team, aliases: [:team_a, :team_b] do
    name 'Brasil'
  end

end