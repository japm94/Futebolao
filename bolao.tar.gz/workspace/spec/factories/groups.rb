FactoryGirl.define do
  
  factory :group do
    name 'A'
  end

end